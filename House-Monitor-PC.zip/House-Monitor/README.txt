HOUSE MONITOR (Windows)
=======================

Start:   double-click  "House Monitor.exe"  (one file: copy it anywhere;
         "House Monitor.exe" --full opens it full screen), or
         "Start House Monitor.bat" / "Start House Monitor (Full Screen).bat"
         - press Alt+F4 to close full screen.
         It opens on the TOP screen: the display that sits highest (the
         monitor above a laptop). With one screen it opens on that one.
         Run "Create Desktop Shortcut.bat" once to get a "House Monitor"
         shortcut with the monitor icon on your desktop.
         The screen starts black: click the dim power button (or press
         Enter) to switch the monitor on; sound starts with it.
         The screen style (House M.D. set monitor or CARESCAPE B450) is in
         Monitor Setup -> Screen Setup.

If Windows asks, choose "More info" -> "Run anyway". The launcher only opens
House-Monitor.html in a Microsoft Edge app window. You can also double-click
House-Monitor.html to open it in any browser (on a phone too). Works fully
offline.

Keys:    Space = Pause Audio    N = NIBP start/stop    F = Freeze
         Z = Zero all           I = Instructor panel   Esc = close menu
         F11 = full screen

The Instructor panel (button at the top right, or the I key) controls the
patient: scenarios, rhythm, ectopy, vital signs, sensor faults, shocks.
Deteriorations run a patient through timed stages on their own (1x/2x/4x);
Build your own timeline makes your own (saved on this computer).

Updates: Instructor -> Software -> Check for updates. It downloads the
newest monitor, keeps it on this computer and restarts (it comes back on if
it was on). Needs internet only for the check.
It opens in its own window (put it on a second screen); move the mouse to
show the faded Instructor button. The monitor fills the window with no
drawn frame (Monitor Setup -> Show monitor housing turns one on).

House M.D. screen: the header, labels, keys, bezel buttons and battery all
work (click them). ◀◀ / ▶▶ switch between two pages of keys. Realtime and
Delayed Record save waveform strips under Data & Pages -> Recordings.

Fonts embedded for the House screen: Archivo Narrow (SIL Open Font License
1.1) and Roboto Condensed (Apache License 2.0).

Training/hobby simulation only. Not a medical device, never use with a real
patient. Not affiliated with or endorsed by GE HealthCare; CARESCAPE is a
GE HealthCare trademark, used only to describe what this resembles.
